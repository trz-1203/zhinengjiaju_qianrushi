<template>
  <div class="wrapper">
    <div class="header-wrapper">
      <div class="header-title">
        <span>空气质量-{{airText}}</span>
        <span>{{area}}-{{city}}</span>
      </div>
      <div class="header-text">
        <span>{{airValue}}</span>
        <span>{{weather}}</span>
      </div>
      <div class="weather-advice">{{weatherAdvice}}</div>
    </div>
    <div class="body-wrapper">
      <div class="body">
        <div class="data-wrapper">
          <div class="data">
            <img class="data-logo" src="/static/images/temperature.png"/>
            <div class="data-text">
              <div class="data-title">温度</div>
              <div class="data-value">{{Temp}}℃</div>
            </div>
          </div>
          <div class="data">
            <img class="data-logo" src="/static/images/humidity.png"/>
            <div class="data-text">
              <div class="data-title">湿度</div>
              <div class="data-value">{{Humi}}%</div>
            </div>
          </div>
        </div>
        <div class="data-wrapper">
          <div class="data">
            <img class="data-logo" src="/static/images/light.png"/>
            <div class="data-text">
              <div class="data-title">光照度</div>
              <div class="data-value">{{Light}}Lx</div>
            </div>
          </div>
          <div class="data">
            <img class="data-logo" src="/static/images/MQ.png"/>
            <div class="data-text">
              <div class="data-title">有害气体指数</div>
              <div class="data-value">{{Aq}}pm</div>
            </div>
          </div>
        </div>
        <div class="data-wrapper">
          <div class="data">
            <img class="data-logo" src="/static/images/alarm.png"/>
            <div class="data-text">
              <div class="data-title">报警器</div>
              <div class="data-value">
                <switch @change="onBeepChange" :checked="Beep" color="#3d7ef9" />
              </div>
            </div>
          </div>
          <div class="data">
            <img class="data-logo" src="/static/images/windows.png"/>
            <div class="data-text">
              <div class="data-title">窗帘</div>
              <div class="data-value">
                <switch @change="onWindowsChange" :checked="Windows" color="#3d7ef9" />
              </div>
            </div>
          </div>
        </div>
        <div class="data-wrapper">
          <div class="data">
            <img class="data-logo" src="/static/images/led.png"/>
            <div class="data-text">
              <div class="data-title">客厅灯</div>
              <div class="data-value">
                <switch @change="onLedChange" :checked="Led" color="#3d7ef9" />
              </div>
            </div>
          </div>
          <div class="data">
            <img class="data-logo" src="/static/images/door.png"/>
            <div class="data-text">
              <div class="data-title">门</div>
              <div class="data-value">
                <switch @change="onDoorChange" :checked="Door" color="#3d7ef9" />
              </div>
            </div>
          </div>
        </div>
        <div class="data-wrapper">
          <div class="data">
            <img class="data-logo" src="/static/images/fans.png"/>
            <div class="data-text">
              <div class="data-title">风扇</div>
              <div class="data-value">
                <switch @change="onFanChange" :checked="Fan" color="#3d7ef9" />
              </div>
            </div>
          </div>
          <div class="data">
            <img class="data-logo" src="/static/images/ModeChange.png"/>
            <div class="data-text">
              <div class="data-title">模式切换</div>
              <div class="data-value">
                <switch @change="onModeChange" :checked="Mode" color="#3d7ef9" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { connect } from "mqtt/dist/mqtt.js";

const mqttUrl = 'wxs://***.***.****:8084/mqtt';//这里填你自己的服务器

export default {
  data () {
    return {
      client:{},
      Temp:0,
      Humi:0,
      Light:0,
      Aq:0,
      Led:false,
      Beep:false,
      Windows:false,
      Door:false,
      fan:false,
      mode:false,
      area:'请求中',//区域
      city:'请求中',//城市
      airText:'请求中',//空气情况
      airValue:0,//空气指数
      weather:'请求中',//天气
      weatherAdvice:'请求中'//出行建议
    };
  },

  components: {
  },

  methods: {
    onLedChange(event){
      //这句加不加好像都没有问题
      var that = this
      //用了npvue进行封装
      console.log(event.mp.detail)
      let sw = event.mp.detail.value
      that.Led = sw
      if(sw){
        that.client.publish('/mysmarthome/sub','{"target":"LED","value":1}',function(err){
          if(!err){
            console.log("成功开启命令——开灯")
          }
        })
      }
      else{
        that.client.publish('/mysmarthome/sub','{"target":"LED","value":0}',function(err){
          if(!err){
            console.log("成功开启命令——关灯")
          }
        })
      }
    },
    onBeepChange(event){
      //这句加不加好像都没有问题
      var that = this
      //用了npvue进行封装
      console.log(event.mp.detail)
      let sw = event.mp.detail.value
      that.Beep = sw
      if(sw){
        that.client.publish('/mysmarthome/sub','{"target":"BEEP","value":1}',function(err){
          if(!err){
            console.log("成功开启命令——开蜂鸣器")
          }
        })
      }
      else{
        that.client.publish('/mysmarthome/sub','{"target":"BEEP","value":0}',function(err){
          if(!err){
            console.log("成功开启命令——关蜂鸣器")
          }
        })
      }
    },
    onWindowsChange(event){
      //这句加不加好像都没有问题
      var that = this
      //用了npvue进行封装
      console.log(event.mp.detail)
      let sw = event.mp.detail.value
      that.Windows = sw
      if(sw){
        that.client.publish('/mysmarthome/sub','{"target":"Windows","value":1}',function(err){
          if(!err){
            console.log("成功开启命令——打开窗户")
          }
        })
      }
      else{
        that.client.publish('/mysmarthome/sub','{"target":"Windows","value":0}',function(err){
          if(!err){
            console.log("成功开启命令——关上窗户")
          }
        })
      }
    },
    onDoorChange(event){
      //这句加不加好像都没有问题
      var that = this
      //用了npvue进行封装
      console.log(event.mp.detail)
      let sw = event.mp.detail.value
      that.Door = sw
      if(sw){
        that.client.publish('/mysmarthome/sub','{"target":"Door","value":1}',function(err){
          if(!err){
            console.log("成功开启命令——开门")
          }
        })
      }
      else{
        that.client.publish('/mysmarthome/sub','{"target":"Door","value":0}',function(err){
          if(!err){
            console.log("成功开启命令——关门")
          }
        })
      }
    },
    onFanChange(event){
      //这句加不加好像都没有问题
      var that = this
      //用了npvue进行封装
      console.log(event.mp.detail)
      let sw = event.mp.detail.value
      that.Fan = sw
      if(sw){
        that.client.publish('/mysmarthome/sub','{"target":"Fan","value":1}',function(err){
          if(!err){
            console.log("成功开启命令——打开风扇")
          }
        })
      }
      else{
        that.client.publish('/mysmarthome/sub','{"target":"Fan","value":0}',function(err){
          if(!err){
            console.log("成功开启命令——关闭风扇")
          }
        })
      }
    },
    onModeChange(event){
      //这句加不加好像都没有问题
      var that = this
      //用了npvue进行封装
      console.log(event.mp.detail)
      let sw = event.mp.detail.value
      that.Mode = sw
      if(sw){
        that.client.publish('/mysmarthome/sub','{"target":"Mode","value":1}',function(err){
          if(!err){
            console.log("成功开启命令——离家模式")
          }
        })
      }
      else{
        that.client.publish('/mysmarthome/sub','{"target":"Mode","value":0}',function(err){
          if(!err){
            console.log("成功开启命令——居家模式")
          }
        })
      }
    }
  },
  //created () {
    // let app = getApp()
  //}
  //小程序生命周期
  onShow(){
    var that = this
    that.client = connect(mqttUrl)
    that.client.on('connect',function (){
      console.log("成功连接服务器！")
      that.client.subscribe("/mysmarthome/pub",function (err){
        if(!err){
          console.log("成功订阅设备上行数据Topic!")
        }
      })
    })
    that.client.on('message',function (topic,message){
      console.log(topic)
      //console.log(message)
      //message是16进制的Buffer字节流，需要ASCII转换
      let dataFromDev = {}
      dataFromDev = JSON.parse(message)
      console.log(dataFromDev)
      that.Temp = dataFromDev.Temp
      that.Humi = dataFromDev.Humi
      that.Light = dataFromDev.Light
      that.Aq = dataFromDev.Aq
      that.Led = dataFromDev.Led
      that.Beep = dataFromDev.Beep
      that.Windows = dataFromDev.Windows
      that.Door = dataFromDev.Door
      that.Fan = dataFromDev.Fan
      that.Mode = dataFromDev.Mode
    });

    wx.getLocation({
      type: 'wgs84',
      success (res) {
        const latitude = res.latitude//纬度
        const longitude = res.longitude//经度
        const key = '663931e37f4d497e8f420f5e3d7c****'//这里填自己申请的天气密钥（用的和风天气）
        wx.request({
          url: `https://free-api.heweather.net/s6/weather/now?location=${longitude},${latitude}&key=${key}`, //获取天气数据的API接口地址
          success (res) {
            //console.log(res.data)
            const {basic,now} = res.data.HeWeather6[0]
            //console.log(basic)
            //console.log(now)
            that.area = basic.location
            that.city = basic.parent_city
            that.weather = now.cond_txt 
            wx.request({
              url: `https://free-api.heweather.net/s6/air/now?location=${that.city}&key=${key}`, //获取空气质量数据
              success (res) {
                //console.log(res.data)
                //const {basic,now} = res.data.HeWeather6[0]
                //console.log(res.data)
                const { air_now_city } = res.data.HeWeather6[0];
                //console.log(air_now_city)
                const {aqi,qlty} = air_now_city
                that.airText = qlty
                that.airValue = aqi
              }
            })
          }
        });
        wx.request({
              url: `https://free-api.heweather.net/s6/weather/lifestyle?location=${longitude},${latitude}&key=${key}`, //获取空气质量数据
              success (res) {
                //console.log(res.data)
                //const {basic,now} = res.data.HeWeather6[0]
                console.log(res.data)
                const {lifestyle} = res.data.HeWeather6[0];
                console.log(lifestyle)
                that.weatherAdvice = lifestyle[1].txt
              }
        })
      }
    });
  }
};

</script>

<style lang="scss" scoped>
.wrapper{
  padding: 15px;
  .header-wrapper{              //编辑小程序头部
    background-color: #296ce9;//背景为蓝色
    border-radius: 20px;
    color: #fff;//字体为白色
    box-shadow: #d6d6d6 0px 0px 5px;//阴影效果
    padding: 15px 30px;//蓝色背景上下边距
    .header-title{
      display: flex;
      justify-content: space-between;//使第一行标题分开
    }
    .header-text{
      font-size: 28px;//第二行字体大小
      font-weight: 400;//字体粗细
      display: flex;
      justify-content: space-between;//将字体分开
    }
    .weather-advice{
      margin-top: 10px;//上边距
      font-size: 14px;//字体大小
    }
  }
  .data-wrapper{
    margin-top: 20px;
    display: flex;
    justify-content: space-between;
    .data{
      background-color: #fff;
      width: 150px;
      height: 80px;
      border-radius: 20px;
      display: flex;
      justify-content: space-around;
      padding: 0 8px;
      box-shadow: #d6d6d6 0px 0px 5px;
      .data-logo{
        height: 36px;
        width: 36px;
        margin-top: 15px;
      }
      .data-text{
        margin-top: 15px;
        color: #7f7f7f;
        .data-title{
          text-align: right;
        }
        .data-value{
          font-size: 26px;
        }
      }
    }
  }
}

</style>
