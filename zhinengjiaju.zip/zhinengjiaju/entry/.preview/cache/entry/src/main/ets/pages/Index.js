import myHome from '@bundle:com.example.zhinengjiaju/entry/ets/view/myHome/myHome';
import roomCondition from '@bundle:com.example.zhinengjiaju/entry/ets/view/roomCondition/roomConditon';
import controlPage from '@bundle:com.example.zhinengjiaju/entry/ets/view/the3rd/controlPage';
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__currentIndex = new ObservedPropertySimplePU(0, this, "currentIndex");
        this.__head = new ObservedPropertySimplePU('房间环境', this, "head");
        this.__room = new ObservedPropertySimplePU('客厅', this, "room");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.currentIndex !== undefined) {
            this.currentIndex = params.currentIndex;
        }
        if (params.head !== undefined) {
            this.head = params.head;
        }
        if (params.room !== undefined) {
            this.room = params.room;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__head.purgeDependencyOnElmtId(rmElmtId);
        this.__room.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentIndex.aboutToBeDeleted();
        this.__head.aboutToBeDeleted();
        this.__room.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get currentIndex() {
        return this.__currentIndex.get();
    }
    set currentIndex(newValue) {
        this.__currentIndex.set(newValue);
    }
    get head() {
        return this.__head.get();
    }
    set head(newValue) {
        this.__head.set(newValue);
    }
    get room() {
        return this.__room.get();
    }
    set room(newValue) {
        this.__room.set(newValue);
    }
    tabBuilder1(title, image, index, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 4 });
            Column.debugLine("pages/Index.ets(17:5)");
            Column.justifyContent(FlexAlign.Center);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(this.currentIndex === index ? { "id": 0, "type": 30000, params: ['image/abbn1(cked).png'], "bundleName": "com.example.zhinengjiaju", "moduleName": "entry" } : { "id": 0, "type": 30000, params: ['image/abbn1(uncked).png'], "bundleName": "com.example.zhinengjiaju", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(18:7)");
            Image.width(20);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(title);
            Text.debugLine("pages/Index.ets(20:7)");
            Text.fontColor(this.currentIndex === index ? Color.Black : Color.Gray);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    tabBuilder2(title, image, index, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 4 });
            Column.debugLine("pages/Index.ets(27:5)");
            Column.justifyContent(FlexAlign.Center);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(this.currentIndex === index ? { "id": 0, "type": 30000, params: ['image/tabbtn2(cked).png'], "bundleName": "com.example.zhinengjiaju", "moduleName": "entry" } : { "id": 0, "type": 30000, params: ['image/tabbtn2(uncked).png'], "bundleName": "com.example.zhinengjiaju", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(28:7)");
            Image.width(20);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(title);
            Text.debugLine("pages/Index.ets(30:7)");
            Text.fontColor(this.currentIndex === index ? Color.Black : Color.Gray);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    tabBuilder3(title, image, index, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 4 });
            Column.debugLine("pages/Index.ets(36:3)");
            Column.justifyContent(FlexAlign.Center);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(this.currentIndex === index ? { "id": 0, "type": 30000, params: ['image/tabbtn3(cked).png'], "bundleName": "com.example.zhinengjiaju", "moduleName": "entry" } : { "id": 0, "type": 30000, params: ['image/tabbtn3(uncked).png'], "bundleName": "com.example.zhinengjiaju", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(37:5)");
            Image.width(20);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(title);
            Text.debugLine("pages/Index.ets(39:5)");
            Text.fontColor(this.currentIndex === index ? Color.Black : Color.Gray);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Tabs.create({ barPosition: BarPosition.End });
            Tabs.debugLine("pages/Index.ets(45:5)");
            Tabs.onChange(index => this.currentIndex = index);
            Tabs.width('100%');
            Tabs.height('100%');
            Tabs.vertical(false);
            if (!isInitialRender) {
                Tabs.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new myHome(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.tabBuilder1.call(this, `首页`, { "id": 0, "type": 30000, params: ['image/abbn1(uncked).png'], "bundleName": "com.example.zhinengjiaju", "moduleName": "entry" }, 0);
                } });
            TabContent.debugLine("pages/Index.ets(47:7)");
            if (!isInitialRender) {
                // page1
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new roomCondition(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.tabBuilder2.call(this, `环境`, { "id": 0, "type": 30000, params: ['image/tabbtn2(uncked).png'], "bundleName": "com.example.zhinengjiaju", "moduleName": "entry" }, 1);
                } });
            TabContent.debugLine("pages/Index.ets(52:7)");
            if (!isInitialRender) {
                // page2
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new controlPage(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.tabBuilder3.call(this, `场景`, { "id": 0, "type": 30000, params: ['image/tabbtn3(uncked).png'], "bundleName": "com.example.zhinengjiaju", "moduleName": "entry" }, 2);
                } });
            TabContent.debugLine("pages/Index.ets(57:7)");
            if (!isInitialRender) {
                // page3
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        Tabs.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Index(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Index.js.map