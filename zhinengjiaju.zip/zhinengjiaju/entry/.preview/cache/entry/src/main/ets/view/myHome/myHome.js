export default class myHome extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__funcIndex = new ObservedPropertyObjectPU(7
        // @State function:Array = [`语音识别`,`人脸识别`,`手势识别`,`姿态识别`,`出门警戒`,`智能提醒建议`,`添加`]
        , this, "funcIndex");
        this.__home = new ObservedPropertySimplePU('我的家', this, "home");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.funcIndex !== undefined) {
            this.funcIndex = params.funcIndex;
        }
        if (params.home !== undefined) {
            this.home = params.home;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__funcIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__home.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__funcIndex.aboutToBeDeleted();
        this.__home.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get funcIndex() {
        return this.__funcIndex.get();
    }
    set funcIndex(newValue) {
        this.__funcIndex.set(newValue);
    }
    get home() {
        return this.__home.get();
    }
    set home(newValue) {
        this.__home.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/myHome/myHome.ets(25:5)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/myHome/myHome.ets(26:7)");
            Row.margin({ top: 0 });
            Row.height(20);
            Row.width(`100%`);
            Row.alignItems(VerticalAlign.Bottom);
            Row.justifyContent(FlexAlign.End);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //添加设备
            Button.createWithChild();
            Button.debugLine("view/myHome/myHome.ets(28:9)");
            //添加设备
            Button.margin({ right: 5 });
            if (!isInitialRender) {
                //添加设备
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['imagefor1/添加.png'], "bundleName": "com.example.zhinengjiaju", "moduleName": "entry" });
            Image.debugLine("view/myHome/myHome.ets(29:11)");
            Image.width(18);
            Image.height(18);
            Image.colorFilter(`#ddd`);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //添加设备
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //我的设备
            Button.createWithChild();
            Button.debugLine("view/myHome/myHome.ets(39:9)");
            //我的设备
            Button.border({ width: 1 });
            if (!isInitialRender) {
                //我的设备
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['imagefor1/三横线.png'], "bundleName": "com.example.zhinengjiaju", "moduleName": "entry" });
            Image.debugLine("view/myHome/myHome.ets(40:11)");
            Image.width(15);
            Image.height(15);
            Image.backgroundColor(`white`);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //我的设备
        Button.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/myHome/myHome.ets(54:7)");
            Row.backgroundColor(`#fff`);
            Row.alignItems(VerticalAlign.Top);
            Row.justifyContent(FlexAlign.Start);
            Row.width(`100%`);
            Row.height(43);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.home);
            Text.debugLine("view/myHome/myHome.ets(55:9)");
            Text.fontSize(40);
            Text.margin({ left: 12 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //logo
            Row.create();
            Row.debugLine("view/myHome/myHome.ets(65:7)");
            //logo
            Row.width(`100%`);
            //logo
            Row.height(`40%`);
            //logo
            Row.backgroundColor(`#fff`);
            //logo
            Row.justifyContent(FlexAlign.Center);
            if (!isInitialRender) {
                //logo
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['imagefor1/首页.png'], "bundleName": "com.example.zhinengjiaju", "moduleName": "entry" });
            Image.debugLine("view/myHome/myHome.ets(66:9)");
            Image.width(200);
            Image.height(200);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //logo
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //模块
            Row.create();
            Row.debugLine("view/myHome/myHome.ets(75:7)");
            //模块
            Row.justifyContent(FlexAlign.Start);
            //模块
            Row.alignItems(VerticalAlign.Center);
            //模块
            Row.width(`100%`);
            //模块
            Row.height(`10%`);
            //模块
            Row.backgroundColor(`#fff`);
            if (!isInitialRender) {
                //模块
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("view/myHome/myHome.ets(77:9)");
            Button.width(160);
            Button.height(55);
            Button.border({ radius: 3, color: `#e3e3e3`, width: 1 });
            Button.backgroundColor(`#fff`);
            Button.margin({ left: 10, right: 10 });
            Button.alignSelf(ItemAlign.Start);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/myHome/myHome.ets(78:11)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['imagefor1/语音识别.png'], "bundleName": "com.example.zhinengjiaju", "moduleName": "entry" });
            Image.debugLine("view/myHome/myHome.ets(79:13)");
            Image.width(30);
            Image.height(30);
            Image.margin({ left: 1 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`语音识别`);
            Text.debugLine("view/myHome/myHome.ets(81:13)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("view/myHome/myHome.ets(86:9)");
            Button.width(160);
            Button.height(55);
            Button.border({ radius: 3, color: `#e3e3e3`, width: 1 });
            Button.backgroundColor(`#fff`);
            Button.margin({ left: 10, right: 10 });
            Button.alignSelf(ItemAlign.Start);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/myHome/myHome.ets(87:11)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['imagefor1/人脸识别.png'], "bundleName": "com.example.zhinengjiaju", "moduleName": "entry" });
            Image.debugLine("view/myHome/myHome.ets(88:13)");
            Image.width(30);
            Image.height(30);
            Image.margin({ left: 1 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`人脸识别`);
            Text.debugLine("view/myHome/myHome.ets(90:13)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Button.pop();
        //模块
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/myHome/myHome.ets(102:7)");
            Row.justifyContent(FlexAlign.Start);
            Row.alignItems(VerticalAlign.Center);
            Row.width(`100%`);
            Row.height(`10%`);
            Row.backgroundColor(`#fff`);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("view/myHome/myHome.ets(103:9)");
            Button.width(160);
            Button.height(55);
            Button.border({ radius: 3, color: `#e3e3e3`, width: 1 });
            Button.backgroundColor(`#fff`);
            Button.margin({ left: 10, right: 10 });
            Button.alignSelf(ItemAlign.Start);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/myHome/myHome.ets(104:11)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['imagefor1/手势识别.png'], "bundleName": "com.example.zhinengjiaju", "moduleName": "entry" });
            Image.debugLine("view/myHome/myHome.ets(105:13)");
            Image.width(30);
            Image.height(30);
            Image.margin({ left: 1 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`手势识别`);
            Text.debugLine("view/myHome/myHome.ets(107:13)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("view/myHome/myHome.ets(112:9)");
            Button.width(160);
            Button.height(55);
            Button.border({ radius: 3, color: `#e3e3e3`, width: 1 });
            Button.backgroundColor(`#fff`);
            Button.margin({ left: 10, right: 10 });
            Button.alignSelf(ItemAlign.Start);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/myHome/myHome.ets(113:11)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['imagefor1/姿态识别.png'], "bundleName": "com.example.zhinengjiaju", "moduleName": "entry" });
            Image.debugLine("view/myHome/myHome.ets(114:13)");
            Image.width(30);
            Image.height(30);
            Image.margin({ left: 1 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`姿态识别`);
            Text.debugLine("view/myHome/myHome.ets(116:13)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Button.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/myHome/myHome.ets(127:7)");
            Row.justifyContent(FlexAlign.Start);
            Row.alignItems(VerticalAlign.Center);
            Row.width(`100%`);
            Row.height(`10%`);
            Row.backgroundColor(`#fff`);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("view/myHome/myHome.ets(128:9)");
            Button.width(160);
            Button.height(55);
            Button.border({ radius: 3, color: `#e3e3e3`, width: 1 });
            Button.backgroundColor(`#fff`);
            Button.margin({ left: 10, right: 10 });
            Button.alignSelf(ItemAlign.Start);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/myHome/myHome.ets(129:11)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['imagefor1/出门警戒.png'], "bundleName": "com.example.zhinengjiaju", "moduleName": "entry" });
            Image.debugLine("view/myHome/myHome.ets(130:13)");
            Image.width(30);
            Image.height(30);
            Image.margin({ left: 1 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`出门警戒`);
            Text.debugLine("view/myHome/myHome.ets(132:13)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("view/myHome/myHome.ets(137:9)");
            Button.width(160);
            Button.height(55);
            Button.border({ radius: 3, color: `#e3e3e3`, width: 1 });
            Button.backgroundColor(`#fff`);
            Button.margin({ left: 10, right: 10 });
            Button.alignSelf(ItemAlign.Start);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/myHome/myHome.ets(138:11)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['imagefor1/智能助手提醒.png'], "bundleName": "com.example.zhinengjiaju", "moduleName": "entry" });
            Image.debugLine("view/myHome/myHome.ets(139:13)");
            Image.width(30);
            Image.height(30);
            Image.margin({ left: 1 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`智能提醒建议`);
            Text.debugLine("view/myHome/myHome.ets(141:13)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Button.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/myHome/myHome.ets(152:7)");
            Row.justifyContent(FlexAlign.Start);
            Row.alignItems(VerticalAlign.Center);
            Row.width(`100%`);
            Row.height(`10%`);
            Row.backgroundColor(`#fff`);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("view/myHome/myHome.ets(153:9)");
            Button.width(160);
            Button.height(55);
            Button.border({ radius: 3, color: `#e3e3e3`, width: 1 });
            Button.backgroundColor(`#fff`);
            Button.margin({ left: 10, right: 10 });
            Button.alignSelf(ItemAlign.Start);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/myHome/myHome.ets(154:11)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 0, "type": 30000, params: ['imagefor1/添加.png'], "bundleName": "com.example.zhinengjiaju", "moduleName": "entry" });
            Image.debugLine("view/myHome/myHome.ets(155:13)");
            Image.width(30);
            Image.height(30);
            Image.margin({ left: 1 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`添加`);
            Text.debugLine("view/myHome/myHome.ets(157:13)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Button.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=myHome.js.map