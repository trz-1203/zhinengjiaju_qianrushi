class Sunshine extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.iron = undefined;
        this.title = undefined;
        this.__comfortability = new ObservedPropertySimplePU('', this, "comfortability");
        this.image = undefined;
        this.__show = new ObservedPropertySimplePU(0, this, "show");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.iron !== undefined) {
            this.iron = params.iron;
        }
        if (params.title !== undefined) {
            this.title = params.title;
        }
        if (params.comfortability !== undefined) {
            this.comfortability = params.comfortability;
        }
        if (params.image !== undefined) {
            this.image = params.image;
        }
        if (params.show !== undefined) {
            this.show = params.show;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__comfortability.purgeDependencyOnElmtId(rmElmtId);
        this.__show.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__comfortability.aboutToBeDeleted();
        this.__show.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get comfortability() {
        return this.__comfortability.get();
    }
    set comfortability(newValue) {
        this.__comfortability.set(newValue);
    }
    get show() {
        return this.__show.get();
    }
    set show(newValue) {
        this.__show.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/roomCondition/roomConditon.ets(20:5)");
            Row.height('10%');
            Row.width('90%');
            Row.backgroundColor('#cfcfcf');
            Row.margin({ top: '20', bottom: '10' });
            Row.borderRadius(30);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create($rawfile(this.iron));
            Image.debugLine("view/roomCondition/roomConditon.ets(21:7)");
            Image.height(50);
            Image.width(50);
            Image.margin({ left: 15 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.title);
            Text.debugLine("view/roomCondition/roomConditon.ets(25:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.comfortability);
            Text.debugLine("view/roomCondition/roomConditon.ets(26:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("view/roomCondition/roomConditon.ets(27:7)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create($rawfile(this.image));
            Image.debugLine("view/roomCondition/roomConditon.ets(28:7)");
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.show + 'lx');
            Text.debugLine("view/roomCondition/roomConditon.ets(29:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class Temp extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.iron = undefined;
        this.title = undefined;
        this.__comfortability = new ObservedPropertySimplePU('', this, "comfortability");
        this.image = undefined;
        this.show = undefined;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.iron !== undefined) {
            this.iron = params.iron;
        }
        if (params.title !== undefined) {
            this.title = params.title;
        }
        if (params.comfortability !== undefined) {
            this.comfortability = params.comfortability;
        }
        if (params.image !== undefined) {
            this.image = params.image;
        }
        if (params.show !== undefined) {
            this.show = params.show;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__comfortability.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__comfortability.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get comfortability() {
        return this.__comfortability.get();
    }
    set comfortability(newValue) {
        this.__comfortability.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/roomCondition/roomConditon.ets(54:5)");
            Row.height('10%');
            Row.width('90%');
            Row.backgroundColor('#cfcfcf');
            Row.margin({ top: '20', bottom: '10' });
            Row.borderRadius(30);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create($rawfile(this.iron));
            Image.debugLine("view/roomCondition/roomConditon.ets(55:7)");
            Image.height(50);
            Image.width(50);
            Image.margin({ left: 15 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.title);
            Text.debugLine("view/roomCondition/roomConditon.ets(59:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.comfortability);
            Text.debugLine("view/roomCondition/roomConditon.ets(60:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("view/roomCondition/roomConditon.ets(61:7)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create($rawfile(this.image));
            Image.debugLine("view/roomCondition/roomConditon.ets(62:7)");
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.show + '℃');
            Text.debugLine("view/roomCondition/roomConditon.ets(63:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class wetness extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.iron = undefined;
        this.title = undefined;
        this.__show = new ObservedPropertySimplePU(0, this, "show");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.iron !== undefined) {
            this.iron = params.iron;
        }
        if (params.title !== undefined) {
            this.title = params.title;
        }
        if (params.show !== undefined) {
            this.show = params.show;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__show.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__show.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get show() {
        return this.__show.get();
    }
    set show(newValue) {
        this.__show.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/roomCondition/roomConditon.ets(80:5)");
            Row.height('10%');
            Row.width('90%');
            Row.backgroundColor('#cfcfcf');
            Row.margin({ top: '20', bottom: '10' });
            Row.borderRadius(30);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create($rawfile(this.iron));
            Image.debugLine("view/roomCondition/roomConditon.ets(81:7)");
            Image.height(50);
            Image.width(50);
            Image.margin({ left: 15 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.title);
            Text.debugLine("view/roomCondition/roomConditon.ets(85:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("view/roomCondition/roomConditon.ets(86:7)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Progress.create({ value: this.show, total: 100, type: ProgressType.Ring });
            Progress.debugLine("view/roomCondition/roomConditon.ets(87:7)");
            Progress.margin({ right: 10 });
            Progress.width(50);
            if (!isInitialRender) {
                Progress.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.show + '%');
            Text.debugLine("view/roomCondition/roomConditon.ets(90:7)");
            Text.margin({ right: '10' });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class weather extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.iron = undefined;
        this.title = undefined;
        this.__image = new ObservedPropertySimplePU('', this, "image");
        this.__show = new ObservedPropertyObjectPU('', this, "show");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.iron !== undefined) {
            this.iron = params.iron;
        }
        if (params.title !== undefined) {
            this.title = params.title;
        }
        if (params.image !== undefined) {
            this.image = params.image;
        }
        if (params.show !== undefined) {
            this.show = params.show;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__image.purgeDependencyOnElmtId(rmElmtId);
        this.__show.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__image.aboutToBeDeleted();
        this.__show.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get image() {
        return this.__image.get();
    }
    set image(newValue) {
        this.__image.set(newValue);
    }
    get show() {
        return this.__show.get();
    }
    set show(newValue) {
        this.__show.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/roomCondition/roomConditon.ets(110:5)");
            Row.height('10%');
            Row.width('90%');
            Row.backgroundColor('#cfcfcf');
            Row.margin({ top: '20', bottom: '10' });
            Row.borderRadius(30);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create($rawfile(this.iron));
            Image.debugLine("view/roomCondition/roomConditon.ets(111:7)");
            Image.height(50);
            Image.width(50);
            Image.margin({ left: 15 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.title);
            Text.debugLine("view/roomCondition/roomConditon.ets(115:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("view/roomCondition/roomConditon.ets(116:7)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create($rawfile(this.image));
            Image.debugLine("view/roomCondition/roomConditon.ets(117:7)");
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.show);
            Text.debugLine("view/roomCondition/roomConditon.ets(118:7)");
            Text.margin({ right: '10' });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class suggestion extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__adv = new ObservedPropertySimplePU('建议的内容', this, "adv");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.adv !== undefined) {
            this.adv = params.adv;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__adv.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__adv.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get adv() {
        return this.__adv.get();
    }
    set adv(newValue) {
        this.__adv.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/roomCondition/roomConditon.ets(133:5)");
            Row.width('90%');
            Row.height('100');
            Row.backgroundColor('#cecece');
            Row.borderRadius(30);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('建议：');
            Text.debugLine("view/roomCondition/roomConditon.ets(134:7)");
            Text.margin({ top: '0' });
            Text.lineHeight(20);
            Text.fontSize(20);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.adv);
            Text.debugLine("view/roomCondition/roomConditon.ets(138:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export default class roomCondition extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__head = new ObservedPropertySimplePU('房间环境', this, "head");
        this.__room = new ObservedPropertySimplePU('客厅', this, "room");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.head !== undefined) {
            this.head = params.head;
        }
        if (params.room !== undefined) {
            this.room = params.room;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__head.purgeDependencyOnElmtId(rmElmtId);
        this.__room.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__head.aboutToBeDeleted();
        this.__room.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get head() {
        return this.__head.get();
    }
    set head(newValue) {
        this.__head.set(newValue);
    }
    get room() {
        return this.__room.get();
    }
    set room(newValue) {
        this.__room.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/roomCondition/roomConditon.ets(157:5)");
            Column.backgroundColor('#efefef');
            Column.height('100%');
            Column.width('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/roomCondition/roomConditon.ets(158:7)");
            Row.margin({ top: 60 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.head);
            Text.debugLine("view/roomCondition/roomConditon.ets(159:9)");
            Text.fontSize(45);
            Text.fontWeight(FontWeight.Bold);
            Text.textAlign(TextAlign.Center);
            Text.width('75%');
            Text.backgroundColor('#cecece');
            Text.height(60);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.room);
            Text.debugLine("view/roomCondition/roomConditon.ets(166:9)");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.width('25%');
            Text.backgroundColor('#9a9a9a');
            Text.height('60');
            Text.alignSelf(ItemAlign.Center);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new Sunshine(this, {
                        iron: '../../resources/rawfile/image/太阳.png',
                        title: '光照',
                        comfortability: '（适宜）',
                        image: '',
                        show: 1500
                    }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new Temp(this, {
                        iron: '../../resources/rawfile/image/温度.png',
                        title: '温度',
                        comfortability: '（适宜）',
                        image: '',
                        show: 26
                    }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    //湿度
                    wetness(this, {
                        iron: '../../resources/rawfile/image/湿度.png',
                        title: '湿度',
                        show: 80
                    }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    //天气
                    weather(this, {
                        iron: '../../resources/rawfile/image/天气.png',
                        title: '天气',
                        image: '',
                        show: '多云'
                    }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new suggestion(this, {}, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=roomConditon.js.map