export default class controlPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__message = new ObservedPropertySimplePU('Hello World', this, "message");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get message() {
        return this.__message.get();
    }
    set message(newValue) {
        this.__message.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Scroll.create();
            Scroll.debugLine("view/the3rd/controlPage.ets(7:5)");
            Scroll.width('100%');
            if (!isInitialRender) {
                Scroll.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/the3rd/controlPage.ets(8:7)");
            Column.justifyContent(FlexAlign.Start);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('健康护理');
            Text.debugLine("view/the3rd/controlPage.ets(9:9)");
            Text.borderWidth(1);
            Text.fontSize(25);
            Text.borderRadius(25);
            Text.borderColor('#d7d7d7');
            Text.padding({
                left: 50,
                right: 50,
                top: 10,
                bottom: 10
            });
            Text.fontWeight(FontWeight.Bold);
            Text.margin({
                top: 20
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/the3rd/controlPage.ets(24:9)");
            Row.width('100%');
            Row.padding({
                top: 10,
                left: 10,
                right: 10,
                bottom: 10
            });
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("view/the3rd/controlPage.ets(25:11)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://img1.baidu.com/it/u=1770693719,3634278587&fm=253&fmt=auto&app=138&f=PNG?w=500&h=333');
            Image.debugLine("view/the3rd/controlPage.ets(26:13)");
            Image.width('48%');
            Image.height('12%');
            Image.borderRadius(15);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('月子中心');
            Text.debugLine("view/the3rd/controlPage.ets(31:13)");
            Text.width('44%');
            Text.height('11%');
            Text.backgroundColor('#99ffffff');
            Text.borderRadius(15);
            Text.textAlign(TextAlign.Center);
            Text.fontColor('#8B803B');
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Stack.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("view/the3rd/controlPage.ets(42:11)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://img1.baidu.com/it/u=4053217414,3261182807&fm=253&fmt=auto&app=138&f=JPEG?w=778&h=500');
            Image.debugLine("view/the3rd/controlPage.ets(43:13)");
            Image.width('48%');
            Image.height('12%');
            Image.borderRadius(15);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('养老院');
            Text.debugLine("view/the3rd/controlPage.ets(48:13)");
            Text.width('44%');
            Text.height('11%');
            Text.backgroundColor('#99ffffff');
            Text.borderRadius(15);
            Text.textAlign(TextAlign.Center);
            Text.fontColor('#556778');
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Stack.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/the3rd/controlPage.ets(67:9)");
            Row.width('100%');
            Row.padding({
                left: 10,
                right: 10,
                bottom: 10
            });
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("view/the3rd/controlPage.ets(68:11)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://img1.baidu.com/it/u=1612415938,2801233698&fm=253&fmt=auto&app=138&f=JPEG?w=667&h=500');
            Image.debugLine("view/the3rd/controlPage.ets(69:13)");
            Image.width('48%');
            Image.height('12%');
            Image.borderRadius(15);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('福利院');
            Text.debugLine("view/the3rd/controlPage.ets(74:13)");
            Text.width('44%');
            Text.height('11%');
            Text.backgroundColor('#99ffffff');
            Text.borderRadius(15);
            Text.textAlign(TextAlign.Center);
            Text.fontColor('#6D4143');
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Stack.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("view/the3rd/controlPage.ets(84:11)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://img2.baidu.com/it/u=3766305963,1431927793&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=341');
            Image.debugLine("view/the3rd/controlPage.ets(85:13)");
            Image.width('48%');
            Image.height('12%');
            Image.borderRadius(15);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('残障人士中心');
            Text.debugLine("view/the3rd/controlPage.ets(90:13)");
            Text.width('44%');
            Text.height('11%');
            Text.backgroundColor('#99ffffff');
            Text.borderRadius(15);
            Text.textAlign(TextAlign.Center);
            Text.fontColor('#96642E');
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Stack.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //教育护航
            Text.create('教育护航');
            Text.debugLine("view/the3rd/controlPage.ets(109:9)");
            //教育护航
            Text.borderWidth(1);
            //教育护航
            Text.fontSize(25);
            //教育护航
            Text.borderRadius(25);
            //教育护航
            Text.borderColor('#d7d7d7');
            //教育护航
            Text.padding({
                left: 50,
                right: 50,
                top: 10,
                bottom: 10
            });
            //教育护航
            Text.fontWeight(FontWeight.Bold);
            //教育护航
            Text.margin({
                top: 20
            });
            if (!isInitialRender) {
                //教育护航
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //教育护航
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/the3rd/controlPage.ets(124:9)");
            Row.width('100%');
            Row.padding({
                top: 10,
                left: 10,
                right: 10,
                bottom: 10
            });
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("view/the3rd/controlPage.ets(125:11)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://img0.baidu.com/it/u=4287445225,3905129571&fm=253&fmt=auto&app=138&f=JPEG?w=889&h=500');
            Image.debugLine("view/the3rd/controlPage.ets(126:13)");
            Image.width('48%');
            Image.height('12%');
            Image.borderRadius(15);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('特殊学校');
            Text.debugLine("view/the3rd/controlPage.ets(131:13)");
            Text.width('44%');
            Text.height('11%');
            Text.backgroundColor('#99ffffff');
            Text.borderRadius(15);
            Text.textAlign(TextAlign.Center);
            Text.fontColor('#8B803B');
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Stack.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("view/the3rd/controlPage.ets(142:11)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://img2.baidu.com/it/u=3859151840,3512967049&fm=253&fmt=auto&app=138&f=JPEG?w=750&h=500');
            Image.debugLine("view/the3rd/controlPage.ets(143:13)");
            Image.width('48%');
            Image.height('12%');
            Image.borderRadius(15);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('早教中心');
            Text.debugLine("view/the3rd/controlPage.ets(148:13)");
            Text.width('44%');
            Text.height('11%');
            Text.backgroundColor('#99ffffff');
            Text.borderRadius(15);
            Text.textAlign(TextAlign.Center);
            Text.fontColor('#556778');
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Stack.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/the3rd/controlPage.ets(167:9)");
            Row.width('100%');
            Row.padding({
                left: 10,
                right: 10,
                bottom: 10
            });
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("view/the3rd/controlPage.ets(168:11)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fss2.meipian.me%2Fusers%2F2218307%2F13e76e755b794070a06ab22bfca66701.jpeg%3Fmeipian-raw%2Fbucket%2Fivwen%2Fkey%2FdXNlcnMvMjIxODMwNy8xM2U3NmU3NTViNzk0MDcwYTA2YWIyMmJmY2E2NjcwMS5qcGVn%2Fsign%2Fa539c39bfeaedd599d00f01da3743a37.jpg&refer=http%3A%2F%2Fss2.meipian.me&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1721973921&t=a70471dacf96f448feeca42023781e71');
            Image.debugLine("view/the3rd/controlPage.ets(169:13)");
            Image.width('48%');
            Image.height('12%');
            Image.borderRadius(15);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('幼儿园');
            Text.debugLine("view/the3rd/controlPage.ets(174:13)");
            Text.width('44%');
            Text.height('11%');
            Text.backgroundColor('#99ffffff');
            Text.borderRadius(15);
            Text.textAlign(TextAlign.Center);
            Text.fontColor('#6D4143');
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Stack.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("view/the3rd/controlPage.ets(184:11)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://img2.baidu.com/it/u=1151021049,2165944357&fm=253&fmt=auto&app=138&f=JPEG?w=750&h=500');
            Image.debugLine("view/the3rd/controlPage.ets(185:13)");
            Image.width('48%');
            Image.height('12%');
            Image.borderRadius(15);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('托管机构');
            Text.debugLine("view/the3rd/controlPage.ets(190:13)");
            Text.width('44%');
            Text.height('11%');
            Text.backgroundColor('#99ffffff');
            Text.borderRadius(15);
            Text.textAlign(TextAlign.Center);
            Text.fontColor('#96642E');
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Stack.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('定制功能');
            Text.debugLine("view/the3rd/controlPage.ets(209:9)");
            Text.borderWidth(1);
            Text.fontSize(25);
            Text.borderRadius(25);
            Text.borderColor('#d7d7d7');
            Text.padding({
                left: 50,
                right: 50,
                top: 10,
                bottom: 10
            });
            Text.fontWeight(FontWeight.Bold);
            Text.margin({
                top: 20
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/the3rd/controlPage.ets(225:9)");
            Column.width('100%');
            Column.padding({
                top: 10,
                left: 10,
                bottom: 10,
                right: 10
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/the3rd/controlPage.ets(226:11)");
            Row.backgroundColor('#ACD2F6');
            Row.alignItems(VerticalAlign.Top);
            Row.borderRadius(15);
            Row.padding({
                bottom: 15
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('残障人士');
            Text.debugLine("view/the3rd/controlPage.ets(227:13)");
            Text.fontColor('#5F7B90');
            Text.borderRadius(20);
            Text.padding({
                left: 8,
                right: 8,
                top: 8,
                bottom: 8
            });
            Text.backgroundColor('#E6F3FD');
            Text.margin({
                top: 10,
                left: 10
            });
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            Text.borderWidth(1);
            Text.borderColor('#d7d7d7');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("手势识别功能便利聋哑人士\n语音识别功能便利视觉障碍者、残疾人士");
            Text.debugLine("view/the3rd/controlPage.ets(245:13)");
            Text.layoutWeight(1);
            Text.fontSize(16);
            Text.fontColor('#5F7B90');
            Text.fontWeight(FontWeight.Bold);
            Text.textAlign(TextAlign.Center);
            Text.margin({
                left: 10,
                right: 10
            });
            Text.padding({
                top: 10
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/the3rd/controlPage.ets(265:11)");
            Row.backgroundColor('#ACD2F6');
            Row.alignItems(VerticalAlign.Top);
            Row.borderRadius(15);
            Row.padding({
                bottom: 15
            });
            Row.margin({
                top: 15
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('残障人士');
            Text.debugLine("view/the3rd/controlPage.ets(266:13)");
            Text.fontColor('#5F7B90');
            Text.borderRadius(20);
            Text.padding({
                left: 8,
                right: 8,
                top: 8,
                bottom: 8
            });
            Text.backgroundColor('#E6F3FD');
            Text.margin({
                top: 10,
                left: 10
            });
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            Text.borderWidth(1);
            Text.borderColor('#d7d7d7');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("手势识别功能便利聋哑人士\n语音识别功能便利视觉障碍者、残疾人士");
            Text.debugLine("view/the3rd/controlPage.ets(284:13)");
            Text.layoutWeight(1);
            Text.fontSize(16);
            Text.fontColor('#5F7B90');
            Text.fontWeight(FontWeight.Bold);
            Text.textAlign(TextAlign.Center);
            Text.margin({
                left: 10,
                right: 10
            });
            Text.padding({
                top: 10
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/the3rd/controlPage.ets(307:11)");
            Row.backgroundColor('#ACD2F6');
            Row.alignItems(VerticalAlign.Top);
            Row.borderRadius(15);
            Row.padding({
                bottom: 15
            });
            Row.margin({
                top: 15
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('残障人士');
            Text.debugLine("view/the3rd/controlPage.ets(308:13)");
            Text.fontColor('#5F7B90');
            Text.borderRadius(20);
            Text.padding({
                left: 8,
                right: 8,
                top: 8,
                bottom: 8
            });
            Text.backgroundColor('#E6F3FD');
            Text.margin({
                top: 10,
                left: 10
            });
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            Text.borderWidth(1);
            Text.borderColor('#d7d7d7');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("手势识别功能便利聋哑人士\n语音识别功能便利视觉障碍者、残疾人士");
            Text.debugLine("view/the3rd/controlPage.ets(326:13)");
            Text.layoutWeight(1);
            Text.fontSize(16);
            Text.fontColor('#5F7B90');
            Text.fontWeight(FontWeight.Bold);
            Text.textAlign(TextAlign.Center);
            Text.margin({
                left: 10,
                right: 10
            });
            Text.padding({
                top: 10
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/the3rd/controlPage.ets(349:11)");
            Row.backgroundColor('#ACD2F6');
            Row.alignItems(VerticalAlign.Top);
            Row.borderRadius(15);
            Row.padding({
                bottom: 15
            });
            Row.margin({
                top: 15
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('残障人士');
            Text.debugLine("view/the3rd/controlPage.ets(350:13)");
            Text.fontColor('#5F7B90');
            Text.borderRadius(20);
            Text.padding({
                left: 8,
                right: 8,
                top: 8,
                bottom: 8
            });
            Text.backgroundColor('#E6F3FD');
            Text.margin({
                top: 10,
                left: 10
            });
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            Text.borderWidth(1);
            Text.borderColor('#d7d7d7');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("手势识别功能便利聋哑人士\n语音识别功能便利视觉障碍者、残疾人士");
            Text.debugLine("view/the3rd/controlPage.ets(368:13)");
            Text.layoutWeight(1);
            Text.fontSize(16);
            Text.fontColor('#5F7B90');
            Text.fontWeight(FontWeight.Bold);
            Text.textAlign(TextAlign.Center);
            Text.margin({
                left: 10,
                right: 10
            });
            Text.padding({
                top: 10
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
        Column.pop();
        Scroll.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new controlPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=controlPage.js.map